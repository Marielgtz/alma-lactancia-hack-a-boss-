const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

app.post('/api/contact', (req, res) => {
    console.log('Received data:', req.body);
    res.json({ success: true, message: 'Formulario recibido con éxito' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
